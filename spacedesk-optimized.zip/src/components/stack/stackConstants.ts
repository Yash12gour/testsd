export interface StackConfig {
  baseTop: number;
  step: number;
  maxStrips: number;
  radius: number;
  tallThreshold: number;
}

export function getStackConfig(): StackConfig {
  if (typeof window === 'undefined') {
    return { baseTop: 24, step: 96, maxStrips: 4, radius: 24, tallThreshold: 1.8 };
  }
  const w = window.innerWidth;
  if (w < 640) {
    return { baseTop: 12, step: 60, maxStrips: 2, radius: 18, tallThreshold: 1.8 };
  } else if (w < 1024) {
    return { baseTop: 16, step: 80, maxStrips: 3, radius: 20, tallThreshold: 1.8 };
  }
  return { baseTop: 24, step: 96, maxStrips: 4, radius: 24, tallThreshold: 1.8 };
}
